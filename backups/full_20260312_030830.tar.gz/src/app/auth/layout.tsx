// src/app/auth/layout.tsx
export default function Layout({ children }: { children: React.ReactNode }) {
return children;
}