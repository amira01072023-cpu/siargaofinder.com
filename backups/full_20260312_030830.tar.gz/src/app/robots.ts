import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
return {
rules: [
{
userAgent: "*",
allow: "/",
disallow: ["/admin/", "/api/admin/", "/auth"],
},
],
sitemap: "https://www.siargaofinder.com/sitemap.xml",
host: "https://www.siargaofinder.com",
};
}